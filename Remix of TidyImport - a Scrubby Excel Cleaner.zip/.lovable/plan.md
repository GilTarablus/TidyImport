

# TidyImport Security Audit Report

Audit performed against company SECURITY.md standards.

---

## Violations Table

| # | Severity | File(s) | SECURITY.md Section Violated | Description |
|---|----------|---------|------------------------------|-------------|
| 1 | **Critical** | `supabase/functions/map-headers/index.ts` | Section 3: Input Validation | The edge function does not validate `sourceHeaders` or `targetHeaders` input. No type checking, length limits, or schema validation (e.g., with Zod). An attacker could send arbitrary payloads -- huge arrays, non-string values, or injection content -- directly to the AI gateway. The guide mandates: "Validate everything. Trust nothing. Sanitize always." |
| 2 | **Critical** | `supabase/functions/map-headers/index.ts` | Section 4: Rate Limiting | No rate limiting is implemented on the `map-headers` edge function. The guide requires rate limiting on all API endpoints (100 req/min recommended). Anyone can spam this endpoint, causing cost overruns on AI credits and potential denial of service. |
| 3 | **Critical** | `supabase/functions/map-headers/index.ts` | Section 6: Authentication | The edge function does not verify the caller's identity. There is no `Authorization` header check, no `getClaims()` call, and no user session validation. The guide states all proxy endpoints must "Require valid user session." Any anonymous user or bot can invoke this function. |
| 4 | **High** | `supabase/functions/map-headers/index.ts` | Section 7: CORS | CORS is set to `Access-Control-Allow-Origin: *` (wildcard). While acceptable for truly public APIs, the guide recommends origin whitelisting for APIs that proxy to external services, especially when credentials or cost-bearing operations are involved. |
| 5 | **High** | `supabase/functions/map-headers/index.ts` | Section 7: Security Headers | No security headers (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`) are included in responses. The guide requires these on all edge function responses. |
| 6 | **High** | `supabase/functions/map-headers/index.ts` | Section 1: Proxy Pattern -- "Log access" | No audit logging of API usage per user. The Proxy Pattern Rules table mandates: "Maintain audit logs of API usage per user." |
| 7 | **High** | `supabase/config.toml` | Section 6: Authentication (JWT verification) | The `map-headers` function does not have `verify_jwt = false` explicitly set in config.toml, nor does it perform manual JWT verification in code. The function is completely unauthenticated. |
| 8 | **Medium** | `src/pages/Index.tsx` (lines 224-233) | Section 2: Secrets Management -- "NEVER log secrets" | Multiple `console.log` statements output user data (row contents, names, mappings) to the browser console. While not secrets per se, the guide's spirit of "NEVER log" sensitive data applies. These debug logs expose PII (names, emails) in production. |
| 9 | **Medium** | `src/lib/cleaningEngine.ts` (lines 752-777) | Section 2: Secrets Management -- "NEVER log secrets" | `reformatBirthdays` logs sample birthday values (PII) to the console in production. Same concern as above -- debug logging of user data should be removed or gated behind a development flag. |
| 10 | **Medium** | `index.html` | Section 7: Security Headers -- HTML Meta Tags | No `X-Frame-Options`, CSP meta tag, or `format-detection` meta tags are set. The guide provides specific HTML meta tag examples for client-side security that should be implemented. |
| 11 | **Medium** | `src/components/FileUpload.tsx` | Section 8: File Upload -- Magic Bytes | File upload validation only checks MIME type and extension, not actual file content (magic bytes). The guide requires server-side magic byte verification. Since files are processed client-side only (never uploaded to a server), this is medium severity, but the guide still mandates it as a defense-in-depth measure. |
| 12 | **Medium** | `index.html` | General branding | Title still says "Lovable App" instead of "TidyImport" -- not a security issue but noted during audit as it relates to the `<title>` and `og:title` meta tags. |

---

## Remediation Plan

### Critical Fixes (must be done immediately)

**1. Add input validation to `map-headers` edge function**
- Install/use Zod or manual validation to enforce:
  - `sourceHeaders` must be an array of strings, max 200 items, each string max 100 chars
  - `targetHeaders` must be an array of strings, max 50 items
- Reject malformed requests with 400 status

**2. Add authentication to `map-headers` edge function**
- Add `[functions.map-headers] verify_jwt = false` to `supabase/config.toml`
- Add Authorization header check and JWT verification using the anon key pattern from the security guide
- Alternatively, since this app has no auth system, consider a simpler approach like validating the apikey header matches the anon key

**3. Add rate limiting to `map-headers`**
- Implement IP-based rate limiting (e.g., 10 requests per minute per IP)
- Return 429 with Retry-After header when exceeded
- Can use in-memory tracking for simplicity, or a database-backed approach per the guide

### High Fixes

**4. Restrict CORS origins**
- Replace wildcard `*` with specific allowed origins (the preview URL and published URL)
- Use the `getCorsHeaders(req)` pattern from the guide

**5. Add security headers to edge function responses**
- Add `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: strict-origin-when-cross-origin` to all responses

**6. Add audit logging**
- Log request metadata (IP, timestamp, header count) for each `map-headers` invocation
- Do not log actual header content to avoid PII exposure

### Medium Fixes

**7. Remove production console.log statements**
- Remove or gate behind `import.meta.env.DEV` all `console.log` calls in:
  - `src/pages/Index.tsx` (lines 224-233, 315-318, 337, 352-353, 365-366)
  - `src/lib/cleaningEngine.ts` (lines 752-777)

**8. Add HTML security meta tags to `index.html`**
- Add `X-Frame-Options` meta tag
- Add a basic Content Security Policy meta tag
- Update `<title>` and `og:title` to "TidyImport"

**9. Consider client-side magic byte checking for uploads**
- Read first few bytes of uploaded file to verify it matches declared type before parsing

---

## Summary

The most significant risk area is the **unauthenticated, unvalidated, unrate-limited edge function** (`map-headers`). It is the only server-side component and currently violates Sections 1, 3, 4, and 6 of the Security Guide simultaneously. The client-side code is generally well-implemented (CSV injection prevention, file type/size validation, data-only-in-browser processing), but has debug logging that should be cleaned up for production.

